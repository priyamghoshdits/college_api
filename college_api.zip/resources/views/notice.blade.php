<h3>Hi, {{$name}}, </h3>
<p>Subject:- {{$subject}}</p>
Notice:- {!! $body !!}


