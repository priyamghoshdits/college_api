<h3>Hi, {{$name}}, </h3>
We have reset your password, please login and change your password <br>
Password -> {{$password}}<br>

