<?php

namespace App\Http\Controllers;

use App\Models\PayrollEarnings;
use App\Http\Requests\StorePayrollEarningsRequest;
use App\Http\Requests\UpdatePayrollEarningsRequest;

class PayrollEarningsController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StorePayrollEarningsRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(PayrollEarnings $payrollEarnings)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(PayrollEarnings $payrollEarnings)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdatePayrollEarningsRequest $request, PayrollEarnings $payrollEarnings)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(PayrollEarnings $payrollEarnings)
    {
        //
    }
}
