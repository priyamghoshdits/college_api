<?php

namespace App\Http\Controllers;

use App\Models\PayslipUpload;
use App\Http\Requests\StorePayslipUploadRequest;
use App\Http\Requests\UpdatePayslipUploadRequest;

class PayslipUploadController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StorePayslipUploadRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(PayslipUpload $payslipUpload)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(PayslipUpload $payslipUpload)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdatePayslipUploadRequest $request, PayslipUpload $payslipUpload)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(PayslipUpload $payslipUpload)
    {
        //
    }
}
