<?php

namespace App\Http\Controllers;

use App\Models\PreAdmissionPayment;
use App\Http\Requests\StorePreAdmissionPaymentRequest;
use App\Http\Requests\UpdatePreAdmissionPaymentRequest;

class PreAdmissionPaymentController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StorePreAdmissionPaymentRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(PreAdmissionPayment $preAdmissionPayment)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(PreAdmissionPayment $preAdmissionPayment)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdatePreAdmissionPaymentRequest $request, PreAdmissionPayment $preAdmissionPayment)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(PreAdmissionPayment $preAdmissionPayment)
    {
        //
    }
}
